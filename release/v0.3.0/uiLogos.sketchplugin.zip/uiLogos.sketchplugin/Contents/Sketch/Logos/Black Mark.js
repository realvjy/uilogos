@import '../js/common.js'
@import '../js/getLogo.js'
// call get logo fuction
function onRun(context){
    getLogos(context, 'data/logos/mark/black/')
}
